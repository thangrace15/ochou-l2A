import java.util.Scanner;
public class Specialisation{
    private static final int tentativemax = 3;
    private boolean carte;
    private boolean codecorrect;
     public boolean systemedecontroleacces(){
    return carte && codecorrect;
     }

    public Specialisation(boolean carte, boolean codecorrect) {
        this.carte = carte;
        this.codecorrect = codecorrect;
    }

    public boolean isCarte() {
        return carte;
    }

    public boolean isCodecorrect() {
        return codecorrect;
    }

    public boolean alarme(){
         int tentative=0;
         boolean etat=false;
         while (tentative<tentativemax || etat==true){
             if (systemedecontroleacces()){
                 etat=true;
             }
             else{
                 tentative++;

             }
         }
     return etat;
     }

}