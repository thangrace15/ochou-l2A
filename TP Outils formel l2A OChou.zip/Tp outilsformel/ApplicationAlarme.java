import java.util.Scanner;

public class ApplicationAlarme {
    private static final String carteCorrecte = "Salut";
    private static final String codeCorrecte = "42";
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean carte;
        boolean code;
        Modelisation modelisation = new Modelisation();
        while (modelisation.getElementcourant()!= Modelisation.etat.accesaccorde || modelisation.getElementcourant()!= Modelisation.etat.alarme ){
            System.out.println("Entrez la carte : ");
            String carteSaisie = scanner.next();

            System.out.println("Entrez le code : ");
            String codeSaisie = scanner.next();

            carte = carteSaisie.equals(carteCorrecte);
            code = codeSaisie.equals(codeCorrecte);

            Specialisation specialisation = new Specialisation(carte,code);
            modelisation = new Modelisation();
            modelisation.verification(specialisation.isCarte(),specialisation.isCodecorrect());

            if (specialisation.alarme()){
                modelisation.alarme();
            }

        }
    }

}
