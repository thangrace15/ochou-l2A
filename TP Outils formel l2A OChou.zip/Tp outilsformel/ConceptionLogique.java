
import org.junit.Test;

public class ConceptionLogique{
    @Test
    public void testVerification(){
        Modelisation controle=new Modelisation();
        controle.verification(true,true);
        assert(controle.getElementcourant()== Modelisation.etat.accesaccorde);
    }
        @Test
    public void testverification(){
        Modelisation controle=new Modelisation();
        controle.verification(true,false);
        assert(controle.getElementcourant()==Modelisation.etat.accesrefuse);

    }
}
