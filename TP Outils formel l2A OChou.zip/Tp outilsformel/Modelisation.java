import java.util.Scanner;

public class Modelisation {
   enum etat {
        Debut,accesaccorde,accesrefuse,alarme;

    }
    private etat elementcourant;

    public Modelisation() {
        this.elementcourant = etat.Debut;


    }
    public void verification(boolean cartestatic,boolean codestatic){

        if (cartestatic && codestatic){
            System.out.println("Acces accorde");
            this.elementcourant=etat.accesaccorde;
        }
        else{
            System.out.println("Acces refuse");
            this.elementcourant=etat.accesrefuse;
        }

    }
    public void alarme(){
        this.elementcourant=etat.alarme;

    }

    public etat getElementcourant()
    {
        return elementcourant;
    }
}
